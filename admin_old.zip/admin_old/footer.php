
			</div>
			<!-- End Content -->
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->

<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left">&copy; 2013 - Shobdo-Online.com</span>
		<span class="right">
			All Rights Reserved by <a href="http://Shobdo-Online.com" target="_blank" title="The Sweetest CSS Templates WorldWide">Shobdo-Online.com</a>
		</span>
	</div>
</div>



<!-- End Footer -->
<script type="text/javascript" charset="utf-8">
  $(document).ready(function(){
    $("a[rel^='popUp']").prettyPhoto();
  });
</script>  	
</body>
</html>